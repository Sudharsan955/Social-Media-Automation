"""
=======================================================
   Social Media Automation Tool - Basic Level
   Powered by Claude (Anthropic API)
=======================================================

Features:
  - Generate posts for Twitter/X, LinkedIn, Instagram
  - Choose tone: Professional, Casual, Funny, Inspirational
  - Add hashtags automatically
  - Schedule simulation (shows when posts go live)
  - Save all posts to CSV export
  - View post history

Requirements:
  pip install anthropic
"""

import anthropic
import json
import csv
import os
from datetime import datetime, timedelta
import random

# ---- CONFIG ----
client = anthropic.Anthropic()   # Reads ANTHROPIC_API_KEY from env
MODEL  = "claude-sonnet-4-6"

PLATFORMS = {
    "1": "Twitter/X",
    "2": "LinkedIn",
    "3": "Instagram",
    "4": "All Platforms"
}

TONES = {
    "1": "Professional",
    "2": "Casual",
    "3": "Funny",
    "4": "Inspirational"
}

PLATFORM_LIMITS = {
    "Twitter/X":   280,
    "LinkedIn":    3000,
    "Instagram":   2200,
}

HISTORY_FILE = "post_history.csv"


# -------------------------------------------------------
# AI Post Generator
# -------------------------------------------------------
def generate_post(topic: str, platform: str, tone: str) -> dict:
    """Ask Claude to generate a social media post."""

    limit = PLATFORM_LIMITS.get(platform, 300)

    prompt = f"""You are a social media expert. Generate a {tone.lower()} social media post for {platform}.

Topic: {topic}
Platform: {platform}
Tone: {tone}
Character limit: {limit}

Rules:
- Stay within the character limit
- Add 3-5 relevant hashtags at the end
- For Twitter/X: punchy and concise
- For LinkedIn: professional with a clear value statement
- For Instagram: engaging and visual language with emojis

Respond ONLY with a valid JSON object, no markdown, no extra text:
{{
  "post": "the full post text including hashtags",
  "hashtags": ["tag1", "tag2", "tag3"],
  "char_count": 123,
  "tip": "one short posting tip for this platform"
}}
"""

    response = client.messages.create(
        model=MODEL,
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}]
    )

    raw = response.content[0].text.strip()
    raw = raw.replace("```json", "").replace("```", "").strip()
    return json.loads(raw)


def generate_content_ideas(topic: str, count: int = 5) -> list:
    """Generate multiple content angle ideas for a topic."""

    prompt = f"""Give me {count} different social media content angles for the topic: "{topic}"

Respond ONLY with a valid JSON array, no markdown:
[
  {{"angle": "short angle title", "description": "one line description"}},
  ...
]
"""
    response = client.messages.create(
        model=MODEL,
        max_tokens=512,
        messages=[{"role": "user", "content": prompt}]
    )

    raw = response.content[0].text.strip()
    raw = raw.replace("```json", "").replace("```", "").strip()
    return json.loads(raw)


# -------------------------------------------------------
# Schedule Simulator
# -------------------------------------------------------
def simulate_schedule(platform: str) -> str:
    """Return a simulated best posting time for a platform."""

    best_times = {
        "Twitter/X":   ["9:00 AM", "12:00 PM", "5:00 PM", "8:00 PM"],
        "LinkedIn":    ["8:00 AM", "10:00 AM", "12:00 PM", "5:00 PM"],
        "Instagram":   ["8:00 AM", "11:00 AM", "3:00 PM", "7:00 PM"],
    }

    times = best_times.get(platform, ["9:00 AM"])
    chosen = random.choice(times)

    # Add a day offset (today or tomorrow)
    days_offset = random.choice([0, 1])
    date = datetime.now() + timedelta(days=days_offset)
    date_str = date.strftime("%A, %b %d %Y")

    return f"{date_str} at {chosen}"


# -------------------------------------------------------
# CSV History
# -------------------------------------------------------
def save_to_history(records: list):
    """Append posts to CSV history file."""
    file_exists = os.path.isfile(HISTORY_FILE)

    with open(HISTORY_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "timestamp", "platform", "tone", "topic",
            "post", "hashtags", "char_count", "scheduled_time"
        ])
        if not file_exists:
            writer.writeheader()
        writer.writerows(records)

    print(f"\n  ✅  Posts saved to '{HISTORY_FILE}'")


def view_history():
    """Display saved post history from CSV."""
    if not os.path.isfile(HISTORY_FILE):
        print("\n  [!] No history found yet. Generate some posts first.")
        return

    with open(HISTORY_FILE, "r", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    if not rows:
        print("\n  [!] History file is empty.")
        return

    print(f"\n  📋  Post History ({len(rows)} posts)\n" + "─" * 50)
    for i, row in enumerate(rows[-10:], 1):   # Show last 10
        print(f"\n  [{i}] {row['platform']} | {row['tone']} | {row['timestamp'][:16]}")
        print(f"      Topic: {row['topic']}")
        preview = row['post'][:80] + "..." if len(row['post']) > 80 else row['post']
        print(f"      Post : {preview}")


# -------------------------------------------------------
# Display
# -------------------------------------------------------
PLATFORM_ICON = {
    "Twitter/X": "🐦",
    "LinkedIn":  "💼",
    "Instagram": "📸",
}

def print_post(platform: str, result: dict, scheduled: str):
    icon = PLATFORM_ICON.get(platform, "📱")
    print(f"\n  {icon}  {platform}")
    print("  " + "─" * 44)
    print(f"\n{result['post']}\n")
    print(f"  Chars     : {result['char_count']} / {PLATFORM_LIMITS.get(platform, '?')}")
    print(f"  Hashtags  : {' '.join(['#'+h for h in result['hashtags']])}")
    print(f"  Scheduled : {scheduled}")
    print(f"  💡 Tip    : {result['tip']}")


# -------------------------------------------------------
# Modes
# -------------------------------------------------------
def generate_mode():
    print("\n─── Generate Posts ──────────────────────────")

    topic = input("\n  Enter your topic or idea:\n  > ").strip()
    if not topic:
        print("  [!] Topic cannot be empty.")
        return

    # Platform
    print("\n  Choose platform:")
    for k, v in PLATFORMS.items():
        print(f"    [{k}] {v}")
    p_choice = input("  > ").strip()
    if p_choice not in PLATFORMS:
        print("  [!] Invalid choice.")
        return

    # Tone
    print("\n  Choose tone:")
    for k, v in TONES.items():
        print(f"    [{k}] {v}")
    t_choice = input("  > ").strip()
    if t_choice not in TONES:
        print("  [!] Invalid choice.")
        return

    platform_choice = PLATFORMS[p_choice]
    tone = TONES[t_choice]

    # Determine platforms to generate for
    if platform_choice == "All Platforms":
        targets = ["Twitter/X", "LinkedIn", "Instagram"]
    else:
        targets = [platform_choice]

    print(f"\n  Generating {tone} posts for {platform_choice}...\n" + "=" * 50)

    records = []
    for platform in targets:
        try:
            result    = generate_post(topic, platform, tone)
            scheduled = simulate_schedule(platform)
            print_post(platform, result, scheduled)

            records.append({
                "timestamp":      datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "platform":       platform,
                "tone":           tone,
                "topic":          topic,
                "post":           result["post"],
                "hashtags":       ", ".join(result["hashtags"]),
                "char_count":     result["char_count"],
                "scheduled_time": scheduled,
            })
        except Exception as e:
            print(f"\n  [ERROR] {platform}: {e}")

    if records:
        save_choice = input("\n  Save posts to CSV history? (yes/no): ").strip().lower()
        if save_choice in ("yes", "y"):
            save_to_history(records)


def ideas_mode():
    print("\n─── Content Idea Generator ──────────────────")
    topic = input("\n  Enter a broad topic:\n  > ").strip()
    if not topic:
        print("  [!] Topic cannot be empty.")
        return

    print(f"\n  Generating content ideas for '{topic}'...\n")
    try:
        ideas = generate_content_ideas(topic, count=5)
        print("  Here are 5 content angles:\n" + "─" * 44)
        for i, idea in enumerate(ideas, 1):
            print(f"\n  [{i}] {idea['angle']}")
            print(f"       {idea['description']}")
    except Exception as e:
        print(f"  [ERROR] {e}")


# -------------------------------------------------------
# Main Menu
# -------------------------------------------------------
def main():
    print("\n" + "=" * 50)
    print("   📱  Social Media Automation Tool")
    print("       Powered by Claude AI")
    print("=" * 50)

    while True:
        print("\n  What would you like to do?")
        print("  [1] Generate social media posts")
        print("  [2] Brainstorm content ideas")
        print("  [3] View post history")
        print("  [4] Quit")

        choice = input("\n  Your choice: ").strip()

        if choice == "1":
            generate_mode()
        elif choice == "2":
            ideas_mode()
        elif choice == "3":
            view_history()
        elif choice in ("4", "q", "quit"):
            print("\n  Goodbye! Keep creating great content. 🚀\n")
            break
        else:
            print("  [!] Invalid choice. Enter 1–4.")


if __name__ == "__main__":
    main()
