========================================================
   📱 Social Media Automation Tool — README
   Powered by Claude AI (Anthropic)
========================================================

ABOUT
-----
A CLI tool that uses Claude AI to automatically generate
platform-optimized social media posts for Twitter/X,
LinkedIn, and Instagram — with tone control, scheduling
simulation, hashtag generation, and CSV history export.


SETUP
-----
1. Install dependency:
      pip install anthropic

2. Set your Anthropic API key:
      Windows : set ANTHROPIC_API_KEY=your_key_here
      Mac/Linux: export ANTHROPIC_API_KEY=your_key_here

   Get a free API key at: https://console.anthropic.com

3. Run the app:
      python social_media_automation.py


FILES
-----
  social_media_automation.py  → Main application
  sample_topics.txt           → Topic inspiration list
  post_history.csv            → Auto-created when you save posts


FEATURES
--------
  ✅ Generate posts for Twitter/X, LinkedIn, Instagram
  ✅ Or generate for ALL 3 platforms at once
  ✅ Choose tone: Professional, Casual, Funny, Inspirational
  ✅ Auto hashtag generation (3–5 per post)
  ✅ Character count with platform limits
  ✅ Schedule simulation (best time to post)
  ✅ Pro posting tip per platform
  ✅ CSV export with full history
  ✅ Content idea brainstormer (5 angles per topic)
  ✅ View last 10 saved posts


PLATFORM LIMITS
---------------
  Twitter/X  →  280 characters
  LinkedIn   →  3,000 characters
  Instagram  →  2,200 characters


SAMPLE SESSION
--------------
  Choose: [1] Generate social media posts
  Topic  : The future of AI in healthcare
  Platform: [4] All Platforms
  Tone   : [1] Professional

  Output:
  🐦 Twitter/X
  ──────────────────────────
  AI is transforming healthcare — from early cancer
  detection to personalized treatment plans. The future
  is not robots replacing doctors, but AI empowering
  them to save more lives. 🏥
  #AIinHealthcare #MedTech #FutureOfMedicine

  Chars    : 218 / 280
  Scheduled: Saturday, Jun 14 2025 at 9:00 AM
  💡 Tip   : Post between 9–10 AM for max engagement

  ... (LinkedIn and Instagram posts follow)


CONCEPTS USED (BASIC LEVEL)
-----------------------------
  - Anthropic API (Claude) for AI post generation
  - JSON structured output parsing
  - CSV file read/write for history
  - Functions and modular code structure
  - Loops, conditionals, user input
  - datetime for scheduling simulation
  - Error handling with try/except
  - f-strings for clean output formatting


TIPS
----
  - Use "All Platforms" to get 3 posts in one shot
  - Try the "Brainstorm ideas" mode first if you're stuck
  - The CSV history file grows over time — great for review
  - Combine different tones for A/B testing content


========================================================
